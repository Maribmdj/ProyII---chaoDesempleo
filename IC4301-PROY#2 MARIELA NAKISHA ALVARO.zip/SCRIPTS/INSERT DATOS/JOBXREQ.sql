alter table jobxreq auto_increment = 1;

call insert_jobxreq(1,1);
call insert_jobxreq(1,2);
call insert_jobxreq(1,3);
call insert_jobxreq(1,4);
call insert_jobxreq(1,5);
call insert_jobxreq(1,6);
call insert_jobxreq(1,7);
call insert_jobxreq(1,8);
call insert_jobxreq(1,9);
call insert_jobxreq(1,10);