alter table jobxperson auto_increment = 1;

CALL insert_jobxperson('PDF ',4,1);
CALL insert_jobxperson('PDF ',5,1);
CALL insert_jobxperson('PDF ',6,1);
CALL insert_jobxperson('PDF ',8,1);
CALL insert_jobxperson('PDF ',11,1);

CALL insert_jobxperson('PDF ',12,2);
CALL insert_jobxperson('PDF ',13,2);
CALL insert_jobxperson('PDF ',4,2);

CALL insert_jobxperson('PDF ',8,3);
CALL insert_jobxperson('PDF ',10,3);
CALL insert_jobxperson('PDF ',11,3);

CALL insert_jobxperson('PDF ',9,4);
CALL insert_jobxperson('PDF ',12,4);
CALL insert_jobxperson('PDF ',13,4);

CALL insert_jobxperson('PDF ',9,5);
CALL insert_jobxperson('PDF ',9,6);
CALL insert_jobxperson('PDF ',9,7);

CALL insert_jobxperson('PDF ',9,8);
CALL insert_jobxperson('PDF ',12,8);
CALL insert_jobxperson('PDF ',13,8);

CALL insert_jobxperson('PDF ',6,9);
CALL insert_jobxperson('PDF ',7,9);
CALL insert_jobxperson('PDF ',9,9);

CALL insert_jobxperson('PDF ',6,10);
CALL insert_jobxperson('PDF ',7,10);
CALL insert_jobxperson('PDF ',10,10);
CALL insert_jobxperson('PDF ',11,10);

CALL insert_jobxperson('',14,1);
CALL insert_jobxperson('',14,2);
CALL insert_jobxperson('',15,3);
CALL insert_jobxperson('',16,4);
CALL insert_jobxperson('',17,5);
CALL insert_jobxperson('',17,6);
CALL insert_jobxperson('',17,7);
CALL insert_jobxperson('',17,8);
CALL insert_jobxperson('',15,9);
CALL insert_jobxperson('',17,10);
CALL insert_jobxperson('',17,10);
CALL insert_jobxperson('',17,10);

