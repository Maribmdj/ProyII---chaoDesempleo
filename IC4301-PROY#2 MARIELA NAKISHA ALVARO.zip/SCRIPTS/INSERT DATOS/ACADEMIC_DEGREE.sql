call insert_academic_degree('PRIMARIA COMPLETA',1);
call insert_academic_degree('NOVENO AÑO',1);
call insert_academic_degree('SECUNDARIA COMPLETA',1);
call insert_academic_degree('TÉCNICO MEDIO',1);
call insert_academic_degree('TÉCNICO',1);
call insert_academic_degree('BACHILLER UNIVERSITARIO',1);
call insert_academic_degree('LICENCIATURA',1);
call insert_academic_degree('TÉCNICO MEDIO',1);
call insert_academic_degree('MÁSTER',1);

select * from academic_degree