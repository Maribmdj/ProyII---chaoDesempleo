call insert_country('COSTA RICA',1);
call insert_country('PANAMA',1);
call insert_country('NICARAGUA',1);
call insert_country('MEXICO',1);
call insert_country('CANADA',1);

SELECT * FROM COUNTRY;