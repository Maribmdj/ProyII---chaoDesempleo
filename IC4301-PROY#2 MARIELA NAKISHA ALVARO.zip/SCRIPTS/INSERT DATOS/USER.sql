CALL insert_user('mbar','mbar', 1);
CALL insert_user('ndix','ndix',2);
CALL insert_user('amat','amat',3);
CALL insert_user('Roblealto','roblealto',4);
CALL insert_user('conelec','conelec',5);
CALL insert_user('alemsa','alemsa',6);
CALL insert_user('yabala','yabala',7);
CALL insert_user('fervil','fervil',8);
CALL insert_user('indPopulares','indpopulares',9);
CALL insert_user('impmonge','impmonge',10);
CALL insert_user('ferresandoval','ferresandoval',11);
CALL insert_user('bnacional','bnacional',12);
CALL insert_user('bpopular','bpopular',13);
CALL insert_user('jobando','jobando',14);
CALL insert_user('mcampos','mcampos',15);
CALL insert_user('vobando','vobando',16);
CALL insert_user('jaobando','jaobando',17);
CALL insert_user('mmata','mmata',18);
CALL insert_user('ybar','ybar',19);
CALL insert_user('cbar','cbar',20);
CALL insert_user('csandoval','csandoval',21);
CALL insert_user('vmora','vmora',22);
CALL insert_user('dvil','dvil',23);

select * from user;

