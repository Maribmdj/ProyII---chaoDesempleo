#YYYY-MM-DD
#3 admin
call insert_person(115290412, 'MARIELA','BARRANTES','MATA','1993/02/21','FOTO', 1, 16, 22, 45);
call insert_person(115290412, 'NAKISHA','DIXON','','1993/02/21','FOTO', 1, 16, 22, 41);
call insert_person(115290412, 'ÁLVARO','MATARRITA','','1993/02/21','FOTO', 1, 16, 22, 38);

#10 personas
call insert_person(116322929, 'JAZMIN','OBANDO','CAMPOS','1996/04/11','FOTO', 3, 11, 2, 11);
call insert_person(303010753, 'MARISOL','CAMPOS','ARIAS','1969/04/27','FOTO', 3, 16, 5, 11);
call insert_person(119007878, 'VICTORIA','OBANDO','CAMPOS','2006/01/12','FOTO', 3, 16, 10, 11);
call insert_person(00980534, 'JOSE ANTONIO','OBANDO','GUILLEN','1966/03/14','FOTO', 3, 16, 15, 20);
call insert_person(601660591, 'MARIA','MATA','OBANDO','1962/05/10','FOTO', 3, 16, 13, 72);
call insert_person(115340755, 'YENIFER','BARRANTES','MATA','1990/04/11','FOTO', 3, 26, 13, 72);
call insert_person(116324533, 'CHRISTIAN','BARRANTES','MATA','1996/02/07','FOTO', 3, 26, 13, 72);
call insert_person(209872133, 'CHRISTOPHER','SANDOVAL','HERNANDEZ','1987/09/14','FOTO', 3, 9, 10, 45);
call insert_person(234567635, 'VIVANA','MORA','ARAYA','1993/09/28','FOTO', 3, 16, 20, 45);
call insert_person(412590832, 'DYLAN','VILLEGAS','BARRANTES','2007/04/18','FOTO', 3, 26, 20, 72);

#10 empresas
call insert_person(31013452, 'ASOCIACIÓN','ROBLEALTO','S.A.','1990/04/11','FOTO', 2, 26, 13, 72);
call insert_person(31017653, 'CONTROLES','ELÉCTRICOS','DE COSTA RICA','1996/02/07','FOTO', 2, 26, 13, 72);
call insert_person(31018765, 'ALEMSA','ALMACENES','ELÉCTROMECÁNICOS','1987/09/14','FOTO', 2, 9, 10, 45);
call insert_person(31012333, 'KINDER','YABALÁ','CKD','1993/09/28','FOTO', 2, 16, 20, 45);
call insert_person(31017654, 'FERRETERÍA','VILLEGAS','S.A.','2007/04/18','FOTO', 2, 26, 20, 72);
call insert_person(31014512, 'INDUSTRIAS','POPULARES','BARRANTES','1990/04/11','FOTO', 2, 26, 13, 72);
call insert_person(31013232, 'IMPORTADORA','MONGE','','1996/02/07','FOTO', 2, 26, 13, 72);
call insert_person(31017878, 'FERRETERÍA','SANDOVAL','S.A.','1987/09/14','FOTO', 2, 9, 10, 45);
call insert_person(31010984, 'BANCO','NACIONAL','DE COSTA RICA','1993/09/28','FOTO', 2, 16, 20, 45);
call insert_person(31014433, 'BANCO','POPULAR','DE COSTA RICA','2007/04/18','FOTO', 2, 26, 20, 72);

