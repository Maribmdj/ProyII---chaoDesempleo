call insert_typeperson('ADMIN',1);
call insert_typeperson('EMPRESA',1);
call insert_typeperson('PERSONA',1);

