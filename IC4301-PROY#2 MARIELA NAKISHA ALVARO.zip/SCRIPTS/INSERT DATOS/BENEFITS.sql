call insert_benefits('CCSS',1);
call insert_benefits('VACACIONES',1);
call insert_benefits('DÍA LIBRE SEMANAL',1);
call insert_benefits('MEDICO EMPRESA',1);

SELECT * FROM benefits