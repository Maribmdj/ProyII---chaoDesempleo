alter table jobxbenf auto_increment = 1;

call insert_jobxbenf(1,1);
call insert_jobxbenf(1,2);
call insert_jobxbenf(1,3);
call insert_jobxbenf(1,4);
call insert_jobxbenf(1,5);
call insert_jobxbenf(1,6);
call insert_jobxbenf(1,7);
call insert_jobxbenf(1,8);
call insert_jobxbenf(1,9);
call insert_jobxbenf(1,10);

call insert_jobxbenf(3,1);
call insert_jobxbenf(3,2);
call insert_jobxbenf(3,3);
call insert_jobxbenf(3,4);
call insert_jobxbenf(3,5);
call insert_jobxbenf(3,6);
call insert_jobxbenf(3,7);
call insert_jobxbenf(3,8);
call insert_jobxbenf(3,9);
call insert_jobxbenf(3,10);

call insert_jobxbenf(4,1);
call insert_jobxbenf(4,2);
call insert_jobxbenf(4,3);
call insert_jobxbenf(4,4);
call insert_jobxbenf(4,5);
call insert_jobxbenf(4,6);
call insert_jobxbenf(4,7);
call insert_jobxbenf(4,8);
call insert_jobxbenf(4,9);
call insert_jobxbenf(4,10);