call insert_province('SAN JOSÉ',1,1);
call insert_province('ALAJUELA',1,1);
call insert_province('CARTAGO',1,1);
call insert_province('HEREDIA',1,1);
call insert_province('GUANACASTE',1,1);
call insert_province('PUNTARENAS',1,1);
call insert_province('LIMÓN',1,1);

SELECT * FROM province;