#1 CANTONES SAN JOSE
call insert_canton('ACOSTA',1,1);
call insert_canton('ALAJUELITA',1,1);
call insert_canton('ASERRI',1,1);
call insert_canton('CURRIDABAT',1,1);
call insert_canton('DESAMPARADOS',1,1);
call insert_canton('DOTA',1,1);
call insert_canton('ESCAZU',1,1);
call insert_canton('GOICOHECHEA',1,1);
call insert_canton('LEON CORTES CASTRO',1,1);
call insert_canton('MONTES DE OCA',1,1);
call insert_canton('MORA',1,1);
call insert_canton('MORAVIA',1,1);
call insert_canton('PEREZ ZELEDON',1,1);
call insert_canton('PURISCAL',1,1);
call insert_canton('SAN JOSE',1,1);
call insert_canton('SANTA ANA',1,1);
call insert_canton('TARRAZU',1,1);
call insert_canton('TIBAS',1,1);
call insert_canton('TURRUBARES',1,1);
call insert_canton('VAZQUEZ DE CORONADO',1,1);

#2 CANTONES ALAJUELA
call insert_canton('ALAJUELA',1,2);
call insert_canton('SAN RAMON',1,2);
call insert_canton('GRECIA',1,2);
call insert_canton('SAN MATEO',1,2);
call insert_canton('ATENAS',1,2);
call insert_canton('NARANJO',1,2);
call insert_canton('PALMARES',1,2);
call insert_canton('POAS',1,2);
call insert_canton('OROTINA',1,2);
call insert_canton('SAN CARLOS',1,2);
call insert_canton('ZARCERO',1,2);
call insert_canton('VALVERDE VEGA',1,2);
call insert_canton('UPALA',1,2);
call insert_canton('LOS CHILES',1,2);
call insert_canton('GUATUSO',1,2);

#3 CANTONES CARTAGO
  call insert_canton('CARTAGO',1,3);
  call insert_canton('PARAISO',1,3);
  call insert_canton('LA UNION',1,3);
  call insert_canton('JIMENEZ',1,3);
  call insert_canton('TURRIALBA',1,3);
  call insert_canton('ALVARADO',1,3);
  call insert_canton('OREAMUNO',1,3);
  call insert_canton('EL GUARCO',1,3);

#4 CANTONES HEREDIA
call insert_canton('HEREDIA',1,4);
call insert_canton('BARVA',1,4);
call insert_canton('SANTO DOMINGO',1,4);
call insert_canton('SANTA BARBARA',1,4);
call insert_canton('SAN RAFAEL',1,4);
call insert_canton('SAN ISIDRO',1,4);
call insert_canton('BELEN',1,4);
call insert_canton('FLORES',1,4);
call insert_canton('SAN PABLO',1,4);
call insert_canton('SARAPIQUI',1,4);

#5 CANTONES GUANACASTE
call insert_canton('LIBERIA',1,5);
call insert_canton('NOCOYA',1,5);
call insert_canton('SANTA CRUZ',1,5);
call insert_canton('BAGACES',1,5);
call insert_canton('CARRILLO',1,5);
call insert_canton('CAÑAS',1,5);
call insert_canton('ABANGARES',1,5);
call insert_canton('TILARAN',1,5);
call insert_canton('NANDAYURE',1,5);
call insert_canton('LA CRUZ',1,5);
call insert_canton('HOJANCHA',1,5);

#6 CANTONCES PUNTARENAS
call insert_canton('PUNTARENAS',1,6);
call insert_canton('ESPARZA',1,6);
call insert_canton('BUENOS AIRES',1,6);
call insert_canton('MONTES DE ORO',1,6);
call insert_canton('OSA',1,6);
call insert_canton('QUEPOS',1,6);
call insert_canton('GOLFITO',1,6);
call insert_canton('COTO BRUS',1,6);
call insert_canton('PARRITA',1,6);
call insert_canton('CORREDORES',1,6);
call insert_canton('GARABITO',1,6);

#7 CANTONES LIMON
call insert_canton('LIMON',1,7);
call insert_canton('POCOCI',1,7);
call insert_canton('SIQUIRRES',1,7);
call insert_canton('TALAMANCA',1,7);
call insert_canton('MATINA',1,7);
call insert_canton('GUACIMO',1,7);

select * from canton

