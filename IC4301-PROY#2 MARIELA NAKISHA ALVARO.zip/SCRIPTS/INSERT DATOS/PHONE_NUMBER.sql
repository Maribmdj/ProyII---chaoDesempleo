
call insert_pnumber('85213503',3);
call insert_pnumber('85313504',4);
call insert_pnumber('85413505',5);
call insert_pnumber('85513506',6);
call insert_pnumber('85613507',7);
call insert_pnumber('85713508',8);
call insert_pnumber('85813509',9);
call insert_pnumber('85913510',10);
call insert_pnumber('85103511',11);
call insert_pnumber('85113512',12);
call insert_pnumber('85123513',13);
call insert_pnumber('85133514',14);
call insert_pnumber('85143515',15);
call insert_pnumber('85153516',16);
call insert_pnumber('85163517',17);
call insert_pnumber('85173518',18);
call insert_pnumber('85183519',19);
call insert_pnumber('85193520',20);
call insert_pnumber('85203521',21);
call insert_pnumber('85213522',22);
call insert_pnumber('85223523',23);

select * from pnumber;