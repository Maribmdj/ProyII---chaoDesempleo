call insert_industry('AGROPECUARIO',1);
call insert_industry('ALIMENTOS',1);
call insert_industry('SEGUROS',1);
call insert_industry('BEBIDAS Y TABACO',1);
call insert_industry('ALQUILERES',1);
call insert_industry('COMERCIO',1);
call insert_industry('CONSUMO MASIVO',1);
call insert_industry('CONSTRUCCIÓN',1);
call insert_industry('EDITORIAL E IMPRENTA',1);
call insert_industry('EDUCATIVO',1);
call insert_industry('ENTRETENIMIENTO',1);
call insert_industry('FINANCIERO',1);
call insert_industry('PUBLICIDAD',1);
call insert_industry('MERCADEO',1);
call insert_industry('SALUD',1);
call insert_industry('SERVICIOS',1);
call insert_industry('MEDIOS',1);
call insert_industry('TECNOLOGÍA',1);
call insert_industry('TRANSPORTE',1);
call insert_industry('TURISMO',1);
call insert_industry('TELECOMUNICACIONES',1);
call insert_industry('INDUSTRIA QUÍMICA',1);
call insert_industry('ADMINISTRACIÓN',1);

SELECT * FROM INDUSTRY