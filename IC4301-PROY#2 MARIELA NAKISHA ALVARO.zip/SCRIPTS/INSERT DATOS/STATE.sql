call chaodesempleo.insert_state('ACTIVO');
call chaodesempleo.insert_state('INACTIVO');

select * from state;
